<section class="map">
    <div id="map">

    </div>
</section>